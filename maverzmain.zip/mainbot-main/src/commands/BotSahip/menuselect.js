const {MessageMenuOption , MessageMenu , MessageActionRow} = require("discord-buttons")
module.exports = {
  conf: {
    aliases: ["maverzrol"],
    name: "maverzrol",
    help: "maverzrol",
    owner: true
  },
  
      run: async(client,message,args,embed) => {

        /* Select Menü 2. Rolleri */
        
        const KutuRol16 = new MessageMenuOption()
        .setLabel('🎉 Çekiliş Katılımcısı')
        .setDescription(`🎉 Çekiliş Katılımcısı Rolü almak için Tıkla.`)
        .setValue('çekiliş');

        const KutuRol17 = new MessageMenuOption()
        .setLabel('🎁 Etkinlik Katılımcısı')
        .setDescription(`🎁 Etkinlik Katılımcısı Rolü almak için Tıkla`)
        .setValue('etkinlik');

        const KutuRol18 = new MessageMenuOption()
        .setLabel('🗑️ Rolsüz')
        .setDescription(`🗑️ Rollerini Temizlemek İçin Tıkla.`)
        .setValue('rolsuzz');

        /* Select Menü 2 Tanım */

        const Menu2 = new MessageMenu()
        .setID("oyun")
        .setPlaceholder(`Rollerini Almak İçin Tıklayınız.`)
        .addOption(KutuRol16)
        .addOption(KutuRol17)
        .addOption(KutuRol18)


        /* Select Menu 2 */
        const RoleMenu2 = new MessageActionRow()
        .addComponent(Menu2)


        message.channel.send(`🎉 Merhaba Maverz Ailesi!\n\n**Aşağıdan Etkinlik ve Çekiliş'lerden Haberdar olmak için rollerini alabilirsin.**`, {
          components: [
            RoleMenu2],
        });
  }}