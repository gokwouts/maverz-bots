
module.exports = {
  conf: {
    aliases: ["maverzgeldisa"],
    name: "ready",
    owner: true,
  },

  run: async (client, message, args) => {
message.lineReply(`ALEYKÜMSELAM!`)
}}