const Discord = require("discord.js");
const settings = require("../../configs/settings.json")
const { MessageButton,MessageActionRow } = require('discord-buttons');
const moment = require('moment');
require("moment-duration-format");
moment.locale('tr');


module.exports = {
  conf: {
    aliases: ["maverzk"],
    name: "kısayollar",
    owner: true,
  },

  run: async (client, message, args,embed) => {


var giris = new MessageButton()
.setID("Giris")
.setLabel("📫 Sunucuya Katılma Tarihi")
.setStyle("gray")

var cezapuan = new MessageButton()
.setID("Ceza")
.setLabel("🗂️ Ceza Sorgu")
.setStyle("gray")

var isim = new MessageButton()
.setID("isim")
.setLabel("📈 Sunucudaki isim Geçmişin")
.setStyle("gray")

var mesaj = new MessageButton()
.setID("mesaj")
.setLabel("🔖 Mesaj İstatistikleri")
.setStyle("gray")

var ses = new MessageButton()
.setID("ses")
.setLabel("🔊 Ses İstatistikleri")
.setStyle("gray")

let buttons = new MessageActionRow()
.addComponent(giris)
.addComponent(cezapuan)
.addComponent(isim)
.addComponent(mesaj)
.addComponent(ses)



let msg = await message.channel.send({ components: buttons, content: `Kısayol Butonları:`})

let collector = msg.createButtonCollector(async (b) => await b.clicker.user.id !== client.user.id)
    
collector.on("collect", async (button) => {
if(button.id === "Giris") 
{
let member = button.clicker.user.id    
await button.reply.think(true)
await button.reply.edit(`${moment(member.joinedAt).format(`DD/MM/YYYY`)}`)
}
if(button.id === "Ceza") 
{
const cezapuan = require("../../schemas/cezapuan");
const cezas = require("../../schemas/ceza");
let member = button.clicker.user.id
const cezapuanData = await cezapuan.findOne({ guildID: settings.guildID, userID: member });
const cezaData = await cezas.findOne({ guildID: settings.guildID, userID: member });
await button.reply.think(true)
await button.reply.edit(`➭ Sunucu içerisindeki Genel Cezaların : \`${cezapuanData ? cezapuanData.cezapuan.length : 0}\` (Toplam ${cezaData ? cezaData.ceza.length : 0})`)
}
if(button.id === "isim")
{
const nameData = require("../../schemas/names")
let member = button.clicker.user.id
const data = await nameData.findOne({ guildID: settings.guildID, userID: member });
await button.reply.think(true)
await button.reply.edit(data ? data.names.splice(0, 10).map((x, i) => `\`${i + 1}.\` \`${x.name}\` (${x.rol}) , (<@${x.yetkili}>) , **[**\`${moment(x.date).format("LLL")}\`**]**`).join("\n") : "İsim Geçmişine ait Veri bulunamadı!")
}
if(button.id === "mesaj") 
{
const messageUserChannel = require("../../schemas/messageUserChannel");
const messageUser = require("../../schemas/messageUser");
const voiceUserChannel = require("../../schemas/voiceUserChannel");
const voiceUser = require("../../schemas/voiceUser");
let member = button.clicker.user.id
const Active1 = await messageUserChannel.find({ guildID: settings.guildID, userID: member }).sort({ channelData: -1 });
const Active2 = await voiceUserChannel.find({ guildID: settings.guildID, userID: member }).sort({ channelData: -1 });
let messageTop;
Active1.length > 0 ? messageTop = Active1.splice(0, 5).map(x => `<#${x.channelID}>: \`${Number(x.channelData).toLocaleString()} mesaj\``).join("\n") : messageTop = "Veri bulunmuyor."
Active2.length > 0 ? voiceTop = Active2.splice(0, 5).map(x => `<#${x.channelID}>: \`${moment.duration(x.channelData).format("H [saat], m [dakika] s [saniye]")}\``).join("\n") : voiceTop = "Veri bulunmuyor."

const messageData = await messageUser.findOne({ guildID: settings.guildID, userID: member });
const messageWeekly = messageData ? messageData.weeklyStat : 0;

await button.reply.think(true)
await button.reply.edit(`➭ Toplam Chat İstatistiğiniz : ${Number(messageWeekly).toLocaleString()} mesaj\n\n${messageTop}`)
}
if(button.id === "ses")
{
const conf = require("../../configs/sunucuayar.json")
const category = async (parentsArray) => {
const data = await voiceUserParent.find({ guildID: message.guild.id, userID: member.id });
const voiceUserParentData = data.filter((x) => parentsArray.includes(x.parentID));
let voiceStat = 0;
for (var i = 0; i <= voiceUserParentData.length; i++) {
voiceStat += voiceUserParentData[i] ? voiceUserParentData[i].parentData : 0;
}
return moment.duration(voiceStat).format("H [saat], m [dakika] s [saniye]");
};
const voiceUserParent = require("../../schemas/voiceUserParent");
const voiceUserChannel = require("../../schemas/voiceUserChannel");
const voiceUser = require("../../schemas/voiceUser");
let member = button.clicker.user.id
const Active2 = await voiceUserChannel.find({ guildID: settings.guildID, userID: member }).sort({ channelData: -1 });
Active2.length > 0 ? voiceTop = Active2.splice(0, 5).map(x => `<#${x.channelID}>: \`${moment.duration(x.channelData).format("H [saat], m [dakika] s [saniye]")}\``).join("\n") : voiceTop = "Veri bulunmuyor."
const voiceData = await voiceUser.findOne({ guildID: settings.guildID, userID: member });
const voiceWeekly = moment.duration(voiceData ? voiceData.weeklyStat : 0).format("H [saat], m [dakika]");
await button.reply.think(true)
await button.reply.edit(`➭ Toplam Ses İstatistiğiniz : \`${moment.duration(voiceData ? voiceData.topStat : 0).format("H [saat], m [dakika]")}\`
• Public Odalar: \`${await category(conf.publicParents)}\`
• Kayıt Odaları: \`${await category(conf.registerParents)}\`
• Private Odalar: \`${await category(conf.privateParents)}\`
• Alone Odalar: \`${await category(conf.aloneParents)}\`
• Sorun Çözme Odalar: \`${await category(conf.solvingParents)}\`
• Eğlence Odalar: \`${await category(conf.funParents)}\``)
}
}) 
},
};