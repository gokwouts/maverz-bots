const Discord = require("discord.js");
const settings = require("../../configs/settings.json")


const { MessageButton,MessageActionRow } = require('discord-buttons');

module.exports = {
    conf: {
      aliases: ["maverzsetup"],
      name: "logmaverz",
      owner: true,
    },

run: async (client, message, args,embed) => {

  const parent = await message.guild.channels.create('MAVERZ LOG', { type: 'category' });
  await message.guild.channels.create('message-log', { type: 'text', parent: parent.id });
  await message.guild.channels.create('voice-log', { type: 'text', parent: parent.id });
  await message.guild.channels.create('tag-log', { type: 'text', parent: parent.id });
  await message.guild.channels.create('invite-log', { type: 'text', parent: parent.id });
  await message.guild.channels.create('rank-log', { type: 'text', parent: parent.id });
  await message.guild.channels.create('ban-log', { type: 'text', parent: parent.id });
  await message.guild.channels.create('jail-log', { type: 'text', parent: parent.id });
  await message.guild.channels.create('mute-log', { type: 'text', parent: parent.id });
  await message.guild.channels.create('vmute-log', { type: 'text', parent: parent.id });
  await message.guild.channels.create('uyarı-log', { type: 'text', parent: parent.id });
  await message.guild.channels.create('cezapuan-log', { type: 'text', parent: parent.id });
  await message.guild.channels.create('rol-log', { type: 'text', parent: parent.id });
  await message.guild.channels.create('komut-log', { type: 'text', parent: parent.id });
  await message.guild.channels.create('mazaretli-log', { type: 'text', parent: parent.id });
}}