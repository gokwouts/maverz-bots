const Discord = require("discord.js");
const settings = require("../../configs/settings.json");
const conf = require("../../configs/sunucuayar.json")

module.exports = {
  conf: {
    aliases: ["rcontrol","rolsüz"],
    name: "rolsuz",
    owner: true,
  },

  run: async (client, message, args, embed) => {
    let ariscim = message.guild.members.cache.filter(m => m.roles.cache.filter(r => r.id !== message.guild.id).size == 0)
    if(args[0] == "ver") {
        ariscim.forEach(r => {
    r.roles.add(conf.unregRoles)
    })
    message.channel.send(embed
    .setDescription("Sunucuda rolü olmayan \`"+ ariscim.size +"\` kişiye kayıtsız rolü verildi!"))
    } else if(!args[0]) {
    message.channel.send(embed
    .setDescription("Sunucumuzda rolü olmayan \`"+ ariscim.size +"\` kişi var. Bu kişilere kayıtsız rolü vermek için \`.rolsüz ver\` komutunu kullanın!"))    
}
  },
};

//arisden mavera hi hello madır fakır
 