//ELLEŞME BURAYLAR MAVERZ#5000
const conf = require("../configs/sunucuayar.json")
module.exports = async (menu) => {

    await menu.clicker.fetch();
    menu.reply.think(true)

    if (menu.values[0] === "couple") {
        menu.clicker.member.roles.cache.has(conf.sevgilimyok) &&
        menu.clicker.member.roles.cache.has(conf.lgbt)

        menu.clicker.member.roles.add(conf.sevgilimvar)
        menu.clicker.member.roles.remove(conf.sevgilimyok)
        menu.clicker.member.roles.remove(conf.lgbt) 
        setTimeout(() => { 
        menu.reply.edit(`<@!${menu.clicker.id}> başarıyla **Couple** rolünü aldın!`)
    },3000)  
    }
    if(menu.values[0] === "alone") {
        menu.clicker.member.roles.cache.has(conf.sevgilimvar) &&
        menu.clicker.member.roles.cache.has(conf.lgbt)

        menu.clicker.member.roles.add(conf.sevgilimyok)
        menu.clicker.member.roles.remove(conf.sevgilimvar)
        menu.clicker.member.roles.remove(conf.lgbt)  
        setTimeout(() => {
            menu.reply.edit(`<@!${menu.clicker.id}> başarıyla **Alone** rolünü aldın!`)
        },3000)            

    }
    if(menu.values[0] === "lgbt") {
        menu.clicker.member.roles.cache.has(conf.sevgilimyok) &&
        menu.clicker.member.roles.cache.has(conf.sevgilimvar)

        menu.clicker.member.roles.add(conf.lgbt)
        menu.clicker.member.roles.remove(conf.sevgilimyok)
        menu.clicker.member.roles.remove(conf.sevgilimvar)       
        setTimeout(() => {
            menu.reply.edit(`<@!${menu.clicker.id}> başarıyla **LGBT** rolünü aldın!`)
        },3000)            
    }
    if(menu.values[0] === "rolsuz") {
        menu.clicker.member.roles.remove(conf.lgbt)
        menu.clicker.member.roles.remove(conf.sevgilimyok)
        menu.clicker.member.roles.remove(conf.sevgilimvar)       
        setTimeout(() => {
            menu.reply.edit(`<@!${menu.clicker.id}> başarıyla üstünüzdeki **TÜM** rolleri aldım!`)
        },3000)            
    }
    if(menu.values[0] === "vk") {
        menu.clicker.member.roles.add(conf.vkRol)    
        setTimeout(() => {
            menu.reply.edit(`<@!${menu.clicker.id}> başarıyla **VK** rolünü aldın!`)
        },3000)            
    }
    if(menu.values[0] === "çekiliş") {
        menu.clicker.member.roles.add(conf.çekiliş)   
        setTimeout(() => {
            menu.reply.edit(`<@!${menu.clicker.id}> başarıyla **Çekiliş** rolünü aldın!`)
        },3000)    
    }
    if(menu.values[0] === "etkinlik") {
        menu.clicker.member.roles.add(conf.etkinlik)   
        setTimeout(() => {
            menu.reply.edit(`<@!${menu.clicker.id}> başarıyla **Etkinlik** rolünü aldın!`)
        },3000)    
    }
    if(menu.values[0] === "rolsuzz") {
        menu.clicker.member.roles.remove(conf.etkinlik)
        menu.clicker.member.roles.remove(conf.çekiliş)   
        setTimeout(() => {
            menu.reply.edit(`<@!${menu.clicker.id}> başarıyla üstünüzdeki **TÜM** rolleri aldım!`)
        },3000)   
    }
    if (menu.values[0] === "kirmizi") {
        if(!conf.ekipRolu.some(x => menu.clicker.member.roles.cache.has(x)))
        {
        setTimeout(() => {
        menu.reply.edit(`<@!${menu.clicker.id}> Booster olman lazım!`)
        },3000) 
        return }
        menu.clicker.member.roles.cache.has(conf.sarirenk) 
        && menu.clicker.member.roles.cache.has(conf.pemberenk)
        && menu.clicker.member.roles.cache.has(conf.mavirenk) 
        && menu.clicker.member.roles.cache.has(conf.yesilrenk)
        && menu.clicker.member.roles.cache.has(conf.turuncurenk)

        menu.clicker.member.roles.add(conf.kirmizirenk)
        menu.clicker.member.roles.remove(conf.sarirenk)
        menu.clicker.member.roles.remove(conf.pemberenk)
        menu.clicker.member.roles.remove(conf.mavirenk)
        menu.clicker.member.roles.remove(conf.yesilrenk)
        menu.clicker.member.roles.remove(conf.turuncurenk)
        setTimeout(() => { 
        menu.reply.edit(`<@!${menu.clicker.id}> başarıyla **Kırmızı Renk** rolünü aldın!`)
    },3000)  
    }
    if (menu.values[0] === "sari") {
        if(!conf.ekipRolu.some(x => menu.clicker.member.roles.cache.has(x)))
        {
        setTimeout(() => {
        menu.reply.edit(`<@!${menu.clicker.id}> Booster olman lazım!`)
        },3000) 
        return }
        menu.clicker.member.roles.cache.has(conf.kirmizirenk) 
        && menu.clicker.member.roles.cache.has(conf.pemberenk)
        && menu.clicker.member.roles.cache.has(conf.mavirenk) 
        && menu.clicker.member.roles.cache.has(conf.yesilrenk)
        && menu.clicker.member.roles.cache.has(conf.turuncurenk)


        menu.clicker.member.roles.add(conf.sarirenk)
        menu.clicker.member.roles.remove(conf.kirmizirenk)
        menu.clicker.member.roles.remove(conf.pemberenk)
        menu.clicker.member.roles.remove(conf.mavirenk)
        menu.clicker.member.roles.remove(conf.yesilrenk)
        menu.clicker.member.roles.remove(conf.turuncurenk)
        setTimeout(() => { 
        menu.reply.edit(`<@!${menu.clicker.id}> başarıyla **Sarı Renk** rolünü aldın!`)
    },3000)  
    }
    if (menu.values[0] === "mavi") {
        if(!conf.ekipRolu.some(x => menu.clicker.member.roles.cache.has(x)))
        {
        setTimeout(() => {
        menu.reply.edit(`<@!${menu.clicker.id}> Booster olman lazım!`)
        },3000) 
        return }
        menu.clicker.member.roles.cache.has(conf.kirmizirenk) 
        && menu.clicker.member.roles.cache.has(conf.pemberenk)
        && menu.clicker.member.roles.cache.has(conf.sarirenk) 
        && menu.clicker.member.roles.cache.has(conf.yesilrenk)
        && menu.clicker.member.roles.cache.has(conf.turuncurenk)


        menu.clicker.member.roles.add(conf.mavirenk)
        menu.clicker.member.roles.remove(conf.kirmizirenk)
        menu.clicker.member.roles.remove(conf.pemberenk)
        menu.clicker.member.roles.remove(conf.sarirenk)
        menu.clicker.member.roles.remove(conf.yesilrenk)
        menu.clicker.member.roles.remove(conf.turuncurenk)
        setTimeout(() => { 
        menu.reply.edit(`<@!${menu.clicker.id}> başarıyla **Mavi Renk** rolünü aldın!`)
    },3000)  
    }
    if (menu.values[0] === "yesil") {
        if(!conf.ekipRolu.some(x => menu.clicker.member.roles.cache.has(x)))
        {
        setTimeout(() => {
        menu.reply.edit(`<@!${menu.clicker.id}> Booster olman lazım!`)
        },3000) 
        return }
        menu.clicker.member.roles.cache.has(conf.kirmizirenk) 
        && menu.clicker.member.roles.cache.has(conf.pemberenk)
        && menu.clicker.member.roles.cache.has(conf.sarirenk) 
        && menu.clicker.member.roles.cache.has(conf.mavirenk)
        && menu.clicker.member.roles.cache.has(conf.turuncurenk)


        menu.clicker.member.roles.add(conf.yesilrenk)
        menu.clicker.member.roles.remove(conf.kirmizirenk)
        menu.clicker.member.roles.remove(conf.pemberenk)
        menu.clicker.member.roles.remove(conf.sarirenk)
        menu.clicker.member.roles.remove(conf.mavirenk)
        menu.clicker.member.roles.remove(conf.turuncurenk)
        setTimeout(() => { 
        menu.reply.edit(`<@!${menu.clicker.id}> başarıyla **Yeşil Renk** rolünü aldın!`)
    },3000)  
    }
    if (menu.values[0] === "turuncu") {
        if(!conf.ekipRolu.some(x => menu.clicker.member.roles.cache.has(x)))
        {
        setTimeout(() => {
        menu.reply.edit(`<@!${menu.clicker.id}> Booster olman lazım!`)
        },3000) 
        return }
        menu.clicker.member.roles.cache.has(conf.kirmizirenk) 
        && menu.clicker.member.roles.cache.has(conf.pemberenk)
        && menu.clicker.member.roles.cache.has(conf.sarirenk) 
        && menu.clicker.member.roles.cache.has(conf.mavirenk)
        && menu.clicker.member.roles.cache.has(conf.yesilrenk)


        menu.clicker.member.roles.add(conf.turuncurenk)
        menu.clicker.member.roles.remove(conf.kirmizirenk)
        menu.clicker.member.roles.remove(conf.pemberenk)
        menu.clicker.member.roles.remove(conf.sarirenk)
        menu.clicker.member.roles.remove(conf.mavirenk)
        menu.clicker.member.roles.remove(conf.yesilrenk)
        setTimeout(() => { 
        menu.reply.edit(`<@!${menu.clicker.id}> başarıyla **Turuncu Renk** rolünü aldın!`)
    },3000)  
    }
    if (menu.values[0] === "pembe") {
        if(!conf.ekipRolu.some(x => menu.clicker.member.roles.cache.has(x)))
        {
        setTimeout(() => {
        menu.reply.edit(`<@!${menu.clicker.id}> Booster olman lazım!`)
        },3000) 
        return }
        menu.clicker.member.roles.cache.has(conf.kirmizirenk) 
        && menu.clicker.member.roles.cache.has(conf.turuncurenk)
        && menu.clicker.member.roles.cache.has(conf.sarirenk) 
        && menu.clicker.member.roles.cache.has(conf.mavirenk)
        && menu.clicker.member.roles.cache.has(conf.yesilrenk)


        menu.clicker.member.roles.add(conf.pemberenk)
        menu.clicker.member.roles.remove(conf.kirmizirenk)
        menu.clicker.member.roles.remove(conf.turuncurenk)
        menu.clicker.member.roles.remove(conf.sarirenk)
        menu.clicker.member.roles.remove(conf.mavirenk)
        menu.clicker.member.roles.remove(conf.yesilrenk)
        setTimeout(() => { 
        menu.reply.edit(`<@!${menu.clicker.id}> başarıyla **Pembe Renk** rolünü aldın!`)
    },3000)  
    }
    if(menu.values[0] === "rolsuzzz") {
    menu.clicker.member.roles.remove(conf.kirmizirenk)
    menu.clicker.member.roles.remove(conf.sarirenk) 
    menu.clicker.member.roles.remove(conf.pemberenk)
    menu.clicker.member.roles.remove(conf.mavirenk)
    menu.clicker.member.roles.remove(conf.yesilrenk)
    menu.clicker.member.roles.remove(conf.turuncurenk)
    setTimeout(() => {
        menu.reply.edit(`<@!${menu.clicker.id}> başarıyla üstünüzdeki **TÜM** rolleri aldım!`)
    },3000)   
    }
}
module.exports.conf = {
    name: "clickMenu",
  };
