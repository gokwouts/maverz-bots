const { green, red } = require("../../configs/emojis.json") 

module.exports = {
  conf: {
    aliases: ["maverzg","safezone"],
    name: "koruma",
    owner: true,
  },

  run: async (client, message, args,embed) => {
    if(!args[0]){
        message.react(red)
        message.channel.send(embed.setDescription(`Kullanım: **.maverzg** \`aç yada kapat\``)).then(x=>x.delete({timeout:5000}))
        }
        if(args[0] == "aç") {
        message.channel.send(`Sunucu safe alana girdi rollerin ytleri kapatıldı!`)
        message.react(green)
        const yetki1 = message.guild.roles.cache.find(r => r.id === "962064348623274014");//#OWNER
        yetki1.setPermissions(0);
        const yetki2 = message.guild.roles.cache.find(r => r.id === "962064346161217546");//#Ceo
        yetki2.setPermissions(0);
        const yetki3 = message.guild.roles.cache.find(r => r.id === "962064349608968242");//#Yıldız
        yetki3.setPermissions(0);       

     }


       
  
        if(args[0] == "kapat") {
        message.channel.send(`Koruma kapatıldı! Rollerin yetkileri verildi!`)
        message.react(green)
        const yetki1 = message.guild.roles.cache.find(r => r.id === "962064348623274014");//#OWNER
        yetki1.setPermissions(0);
        const yetki2 = message.guild.roles.cache.find(r => r.id === "962064346161217546");//#Ceo
        yetki2.setPermissions(0);
        const yetki3 = message.guild.roles.cache.find(r => r.id === "962064349608968242");//#Yıldız
        yetki3.setPermissions(0);   
        
    }
},
};
